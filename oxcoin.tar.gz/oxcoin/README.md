OXCoin [OXC] - FAST SECURE RARE

QRK hashing - based on the combination of 8 random algorithms

50 OXC per block initial reward. 30 seconds per block on average.
Maximum amount 7,777,777 OXC.

First reduction of the block reward after 77777 blocks to 25 OXC. The reward
is from then on reduced each 120 blocks until it reaches at block 1,049,178 the
minimum reward of 0.0750 OXC. The minimum block reward will last for about one
more year until block 1,913,378. The last block with reward is block 1,913,789,
it gets a reward of 0.0788 OXC. With the last block the amount of OXC issued in
total is 7,777,777.00000 OXC (a bit less than 8 million OXC). Starting with block
1,913,380 the block subsidy is zero.

Enjoy OXC! Spread the word!


Resources:

    o Official OXC forum:        http://oxcoin.com/forum/index.php
    o Official Github sources:  https://github.com/oxcoin/oxcoincoin
    o Windows binaries:         https://github.com/oxcoin/oxcoincoin_binaries

